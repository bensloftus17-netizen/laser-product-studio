Laser Product Studio V5 — Reference-matched poster upgrade

Changes:
- Technical poster: Laser catalogue layout based on the supplied technical sheet. Structured application, purpose, genuine product photo, numbered feature table, verified specification table. No invented dimensions or diagrams.
- Promotional poster: bold white/blue Laser advert based on the supplied 8324 example; major product image, RRP panel when manufacturer price is available, benefit bars.
- Price poster: distinct landscape, retail price-first design.
- app.py: fixes VAT-basis parsing. The original script incorrectly treated every RRP as excluding VAT, even when Laser listed it as including VAT.

Upload only these two replacement files to the TOP LEVEL of your existing GitHub repository:
  poster.py
  app.py

GitHub repository: https://github.com/bensloftus17-netizen/laser-product-studio
Click Add file > Upload files, drop both files in, commit. Render should auto-deploy.
Your website stays at: https://laser-product-studio.onrender.com

Important: Do not upload the ZIP directly to GitHub; extract it first. If Github refuses to replace existing files, edit the corresponding file in Github or delete the previous file and upload the replacement.

Testing performed:
- Generated each of the 3 poster formats as valid PNGs with real supplied product photographs.
- Generated technical PDF and packed it with PNGs into ZIP.
- Tested VAT amount presentation, including explicit 20% VAT derivation where official price is ex VAT.
- Live official site lookup and Render deployment are not part of this local test and require post-upload checks.
